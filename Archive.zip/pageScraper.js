const puppeteer = require('puppeteer');

async function scrapeBackOffice() {
    const browser = await puppeteer.launch({ headless: false }); // Launch browser
    const page = await browser.newPage(); // Create a new page

    // Navigate to the login page
    await page.goto('https://www.marocannonces.com/');

    // Wait for the page to load
    await page.waitForTimeout(1000); // 1-second delay

    // Click the "detail" button
    await page.click('.company-2:nth-child(5) td:nth-child(2)');

    // Wait for the new page to load
    await page.waitForTimeout(1000);

    // Click the "check" button
    await page.click('#nav09 a');

    // Wait for the process to finish
    await page.waitForTimeout(1000); // 1-second delay

    console.log('Process completed.');

    await browser.close(); // Close the browser
}

scrapeBackOffice();
